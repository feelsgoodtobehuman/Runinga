package com.example.tvremote

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

/**
 * A simple Bluetooth TV remote. The phone registers as a Bluetooth HID device
 * (keyboard + consumer-control keys) and sends key presses to the paired TV.
 *
 * Report 1 = keyboard (arrows, Enter), Report 2 = consumer control (volume, home, back...).
 */
@SuppressLint("MissingPermission")
class MainActivity : Activity() {

    companion object {
        // HID report descriptor: keyboard (ID 1) + consumer control (ID 2)
        private val DESCRIPTOR: ByteArray = intArrayOf(
            // Keyboard
            0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x85, 0x01,
            0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00, 0x25, 0x01,
            0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
            0x95, 0x01, 0x75, 0x08, 0x81, 0x01,
            0x95, 0x05, 0x75, 0x01, 0x05, 0x08, 0x19, 0x01, 0x29, 0x05, 0x91, 0x02,
            0x95, 0x01, 0x75, 0x03, 0x91, 0x01,
            0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x65,
            0x05, 0x07, 0x19, 0x00, 0x29, 0x65, 0x81, 0x00,
            0xC0,
            // Consumer control
            0x05, 0x0C, 0x09, 0x01, 0xA1, 0x01, 0x85, 0x02,
            0x15, 0x00, 0x26, 0xFF, 0x03, 0x19, 0x00, 0x2A, 0xFF, 0x03,
            0x75, 0x10, 0x95, 0x01, 0x81, 0x00,
            0xC0
        ).map { it.toByte() }.toByteArray()

        // Keyboard usages
        const val KEY_ENTER = 0x28
        const val KEY_RIGHT = 0x4F
        const val KEY_LEFT = 0x50
        const val KEY_DOWN = 0x51
        const val KEY_UP = 0x52

        // Consumer usages
        const val C_POWER = 0x30
        const val C_MENU = 0x40
        const val C_PLAY_PAUSE = 0xCD
        const val C_NEXT = 0xB5
        const val C_PREV = 0xB6
        const val C_MUTE = 0xE2
        const val C_VOL_UP = 0xE9
        const val C_VOL_DOWN = 0xEA
        const val C_HOME = 0x223
        const val C_BACK = 0x224
    }

    private val handler = Handler(Looper.getMainLooper())
    private var hid: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private var devices: List<BluetoothDevice> = emptyList()

    private lateinit var status: TextView
    private lateinit var spinner: Spinner

    private val adapter: BluetoothAdapter? by lazy {
        (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
    }

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            if (registered) {
                setStatus("Ready. Choose your TV and tap Connect.")
            } else {
                setStatus(
                    "Not registered. Another app may be using the phone's Bluetooth " +
                        "keyboard slot (Error 9). Force-stop other remote/keyboard apps, " +
                        "turn Bluetooth off and on, then reopen this app."
                )
            }
        }

        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> {
                    host = device
                    setStatus("Connected to ${device.name ?: device.address}")
                }
                BluetoothProfile.STATE_CONNECTING ->
                    setStatus("Connecting to ${device.name ?: device.address}...")
                BluetoothProfile.STATE_DISCONNECTED -> {
                    if (host == device) host = null
                    setStatus("Disconnected. Choose your TV and tap Connect.")
                }
            }
        }
    }

    private val serviceListener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
            val h = proxy as BluetoothHidDevice
            hid = h
            val sdp = BluetoothHidDeviceAppSdpSettings(
                "TV Remote",
                "Bluetooth TV remote",
                "TVRemote",
                BluetoothHidDevice.SUBCLASS1_COMBO,
                DESCRIPTOR
            )
            val ok = h.registerApp(sdp, null, null, mainExecutor, callback)
            if (!ok) {
                setStatus(
                    "Could not register as a Bluetooth keyboard. Close other remote apps " +
                        "and restart Bluetooth."
                )
            }
        }

        override fun onServiceDisconnected(profile: Int) {
            hid = null
            host = null
            setStatus("Bluetooth service stopped.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()

        if (adapter == null) {
            setStatus("This phone has no Bluetooth.")
            return
        }
        if (missingPermissions().isEmpty()) startHid()
        else requestPermissions(missingPermissions().toTypedArray(), 1)
    }

    override fun onResume() {
        super.onResume()
        if (adapter != null && missingPermissions().isEmpty()) refreshDevices()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        try {
            hid?.unregisterApp()
            adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, hid)
        } catch (_: Exception) {
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (missingPermissions().isEmpty()) startHid()
        else setStatus("Bluetooth permission is needed. Allow it in the app's settings.")
    }

    private fun missingPermissions(): List<String> {
        if (Build.VERSION.SDK_INT < 31) return emptyList()
        return listOf(
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_ADVERTISE
        ).filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
    }

    private fun startHid() {
        setStatus("Starting Bluetooth remote...")
        refreshDevices()
        adapter?.getProfileProxy(this, serviceListener, BluetoothProfile.HID_DEVICE)
    }

    private fun refreshDevices() {
        val keep = if (::spinner.isInitialized) spinner.selectedItemPosition else 0
        devices = adapter?.bondedDevices?.toList() ?: emptyList()
        val names = devices.map { it.name ?: it.address }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        if (keep in names.indices) spinner.setSelection(keep)
    }

    private fun setStatus(text: String) {
        runOnUiThread { status.text = text }
    }

    // ---- Phone volume buttons control the TV while connected ----

    private fun isVolumeKey(keyCode: Int) =
        keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (isVolumeKey(keyCode) && host != null) {
            sendConsumer(if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) C_VOL_UP else C_VOL_DOWN)
            return true // consume it so the phone's own volume does not change
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (isVolumeKey(keyCode) && host != null) return true
        return super.onKeyUp(keyCode, event)
    }

    // ---- Sending keys ----

    private fun sendKey(code: Int) {
        val h = hid
        val d = host
        if (h == null || d == null) {
            toast("Not connected to a TV")
            return
        }
        h.sendReport(d, 1, byteArrayOf(0, 0, code.toByte(), 0, 0, 0, 0, 0))
        handler.postDelayed({ h.sendReport(d, 1, ByteArray(8)) }, 40)
    }

    private fun sendConsumer(usage: Int) {
        val h = hid
        val d = host
        if (h == null || d == null) {
            toast("Not connected to a TV")
            return
        }
        h.sendReport(d, 2, byteArrayOf((usage and 0xFF).toByte(), (usage shr 8).toByte()))
        handler.postDelayed({ h.sendReport(d, 2, ByteArray(2)) }, 40)
    }

    // ---- UI ----

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }

        status = TextView(this).apply { textSize = 15f; text = "Starting..." }
        root.addView(status)

        spinner = Spinner(this)
        root.addView(spinner, LinearLayout.LayoutParams(-1, dp(52)))

        val connect = plainButton("Connect") {
            val i = spinner.selectedItemPosition
            if (hid == null || i !in devices.indices) {
                toast("Pick a paired TV first")
            } else {
                hid?.connect(devices[i])
            }
        }
        val disconnect = plainButton("Disconnect") {
            host?.let { hid?.disconnect(it) }
        }
        root.addView(row(connect, disconnect))

        val discoverable = plainButton("Make phone visible (to pair with TV)") {
            startActivity(
                Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                    .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120)
            )
        }
        root.addView(discoverable, LinearLayout.LayoutParams(-1, -2))

        root.addView(space(16))

        // Power / Home / Back / Menu
        root.addView(
            row(
                remote("Power") { sendConsumer(C_POWER) },
                remote("Home") { sendConsumer(C_HOME) },
                remote("Back") { sendConsumer(C_BACK) },
                remote("Menu") { sendConsumer(C_MENU) }
            )
        )

        root.addView(space(8))

        // D-pad
        root.addView(row(spacer(), remote("▲", true) { sendKey(KEY_UP) }, spacer()))
        root.addView(
            row(
                remote("◀", true) { sendKey(KEY_LEFT) },
                remote("OK") { sendKey(KEY_ENTER) },
                remote("▶", true) { sendKey(KEY_RIGHT) }
            )
        )
        root.addView(row(spacer(), remote("▼", true) { sendKey(KEY_DOWN) }, spacer()))

        root.addView(space(8))

        // Volume: use the phone's own volume buttons while connected. Mute stays on screen.
        root.addView(row(spacer(), remote("Mute") { sendConsumer(C_MUTE) }, spacer()))
        root.addView(
            TextView(this).apply {
                text = "Use your phone's volume buttons to change the TV volume."
                textSize = 14f
                gravity = android.view.Gravity.CENTER
            }
        )

        // Media
        root.addView(
            row(
                remote("⏮") { sendConsumer(C_PREV) },
                remote("⏯") { sendConsumer(C_PLAY_PAUSE) },
                remote("⏭") { sendConsumer(C_NEXT) }
            )
        )

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun space(heightDp: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(-1, dp(heightDp))
    }

    private fun spacer() = View(this)

    private fun row(vararg views: View): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            views.forEach { v ->
                val lp = LinearLayout.LayoutParams(0, dp(68), 1f)
                lp.setMargins(dp(4), dp(4), dp(4), dp(4))
                addView(v, lp)
            }
        }

    private fun plainButton(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { onClick() }
        }

    /** A remote button. If [repeat] is true, holding it keeps sending the key. */
    @SuppressLint("ClickableViewAccessibility")
    private fun remote(label: String, repeat: Boolean = false, action: () -> Unit): Button {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 18f
        }
        val repeater = object : Runnable {
            override fun run() {
                action()
                handler.postDelayed(this, 120)
            }
        }
        button.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    action()
                    if (repeat) handler.postDelayed(repeater, 400)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    handler.removeCallbacks(repeater)
                }
            }
            true
        }
        return button
    }
}
