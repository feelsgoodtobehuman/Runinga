# TV Remote (Bluetooth)

Turns an Android phone (Android 9+) into a Bluetooth remote: d-pad, OK, Home, Back, Menu, Power, volume, mute and media keys.
It works by registering the phone as a Bluetooth keyboard (HID), so the TV must accept Bluetooth keyboards (Android TV / Google TV do).

## Build and install
1. Install Android Studio and open this `TVRemote` folder. Let Gradle sync finish.
2. On your phone, turn on Developer options and USB debugging, plug it in, and press Run.
   (Or Build > Build APK(s) and copy the APK to the phone.)

## Pair with the TV
1. Open the app and allow the Bluetooth permissions.
2. Tap "Make phone visible", then on the TV open Settings > Remote & Accessories (or Bluetooth) > Add accessory.
3. Pick your phone on the TV and accept the pairing on both devices.
4. Back in the app, choose the TV in the dropdown and tap Connect.

## If you see "Not registered" / Error 9
Android allows only one app at a time to act as the phone's Bluetooth keyboard.
Force-stop other remote/keyboard/gamepad apps (including Bluetooth Keyboard & Mouse),
turn Bluetooth off and on, then open this app again.
